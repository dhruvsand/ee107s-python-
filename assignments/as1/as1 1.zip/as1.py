def main():
    # Start your code below this commend
    print('Hello, world!')    # delete this line
    # End your code above this line

if __name__ == '__main__':
    main()