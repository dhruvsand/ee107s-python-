import random
import math

from gamelib import *

class ZombieCharacter(ICharacter):
	def __init__(self, obj_id, health, x, y, map_view):
		ICharacter.__init__(self, obj_id, health, x, y, map_view)

	def selectBehavior(self):
		prob = random.random()

		# If health is less than 50%, then heal with a 10% probability
		if prob < 0.1 and self.getHealth() < self.getInitHealth() * 0.5:
			return HealEvent(self)

		# Pick a random direction to walk 1 unit (Manhattan distance)
		x_off = random.randint(-1, 1)
		y_off = random.randint(-1, 1)

		# Check the bounds
		map_view = self.getMapView()
		size_x, size_y = map_view.getMapSize()
		x, y = self.getPos()
		if x + x_off < 0 or x + x_off >= size_x:
			x_off = 0
		if y + y_off < 0 or y + y_off >= size_y:
			y_off = 0

		return MoveEvent(self, x + x_off, y + y_off)

class PlayerCharacter(ICharacter):
	global times_healed
	global time_to_scan
	global map_view_temp
	global size_y
	global size_x
	times_healed=0
	time_to_scan=0

	def __init__(self, obj_id, health, x, y, map_view):
		global map_view_temp
		global size_y
		global size_x
		
		ICharacter.__init__(self, obj_id, health, x, y, map_view)
		map_view_temp = self.getMapView()
		size_x, size_y = map_view.getMapSize()
		

		# You may add any instance attributes you find useful to save information between frames

	def selectBehavior(self):
		# Replace the body of this method with your character's behavior
		global times_healed
		global time_to_scan
		global map_view_temp
		global size_y
		global size_x

		if(time_to_scan<=0):
			time_to_scan=3
			return ScanEvent(self)

		x,y = self.getPos()
		scan_data2= self.getScanResults()
		time_to_scan=time_to_scan-1



		if((self.getHealth()<self.getInitHealth()*0.75)and(times_healed<5)):
			times_healed+=1
			return HealEvent(self)


		if(time_to_scan==2):
			for scan_data in scan_data2:
				old_x,old_y = scan_data.getPos()
				if(abs(old_x - x) + abs(old_y - y) <= 1 ):
					return AttackEvent(self,scan_data.getID())	

		
		


		return MoveEvent(self,x,y)

		pass
